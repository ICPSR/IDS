IDS Transposer User Guide Files for Example 1

Files used in the first example in the User Guide (Tables 1-10) are included here.

-- UG_Example_1_v10.xlsx  -- This spreadsheet includes all of the files mentioned in the User Guide, including the five IDS tables created by the IDS Transposer.  Each file is a sheet in the spreadsheet.  Files may be exported to .csv or .tab format for submission to the IDS Transposer.  

-- These files in .csv may be submitted to the IDS Transposer:
    Entity.csv
    Relationship.csv
    CHILDREN_INPUT.csv
    PARENTS_INPUT.csv
    PLACES_INPUT.csv


