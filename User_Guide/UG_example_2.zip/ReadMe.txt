IDS Transposer User Guide Files for Example 2

Files used in the first example in the User Guide (Tables 11-13) are included here.

-- UG_Example_2_v10.xlsx  -- This spreadsheet includes all of the files mentioned in the User Guide, including the five IDS tables created by the IDS Transposer.  Each file is a sheet in the spreadsheet.  Files may be exported to .csv or .tab format for submission to the IDS Transposer.  

-- These files in .csv may be submitted to the IDS Transposer:
    entity_ex2.csv
    relationship_ex2.csv
    births_input.csv
    deaths_input.csv
    marriages_input.csv
    places_input.csv


